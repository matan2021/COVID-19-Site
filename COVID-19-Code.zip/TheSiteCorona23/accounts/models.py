from django.db import models
from django.contrib.auth.models import User


# Create our models here.


class Bed(models.Model):
    """make a Bed object with that fields"""
    DEP = (
        ('Corona', 'Corona'),
        ('ENP', 'ENP'),
        ('Heart', 'Heart'),
        ('Emergency room', 'Emergency room'),
    )
    name = models.CharField(max_length=200, null=True)
    department = models.CharField(max_length=200, null=True, choices=DEP)
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    room_number = models.IntegerField(null=True)
    objects = models.Manager()

    def __str__(self):
        return self.name


class Ventilator(models.Model):
    """make a Ventilator object with that fields"""
    DEP = (
        ('Corona', 'Corona'),
        ('ENP', 'ENP'),
        ('Heart', 'Heart'),
        ('Emergency room', 'Emergency room'),
    )
    name = models.CharField(max_length=200, null=True)
    department = models.CharField(max_length=200, null=True, choices=DEP)
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    room_number = models.IntegerField(null=True)
    ventilator_number = models.IntegerField(null=True)

    objects = models.Manager()

    def __str__(self):
        return self.name


class Patient(models.Model):
    """make a Patient object with that fields"""
    STATUS = (
        ('mildly ill', 'mildly ill'),
        ('medium ill', 'medium ill'),
        ('seriously ill', 'seriously ill'),
        ('dying', 'dying'),
    )
    VEN = (
        ('YES', 'YES'),
        ('NO', 'NO'),
    )
    name = models.CharField(max_length=200, null=True)
    ID = models.CharField(max_length=200, null=True)
    department = 'Corona'
    phone = models.CharField(max_length=200, null=True)
    status = models.CharField(max_length=200, null=True, choices=STATUS)
    need_ven = models.CharField(max_length=200, null=True, choices=VEN)
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    objects = models.Manager()

    def __str__(self):
        return self.name



class Concentration(models.Model):
    """make a Concentration object with that fields"""
    name = models.CharField(max_length=200, null=True)
    Amount = models.IntegerField(null=True)
    objects = models.Manager()

    def __str__(self):
        return str(self.Amount)


class Equipment(models.Model):
    """make a Equipment object with that fields"""
    DEP = (
        ('Corona', 'Corona'),
        ('ENP', 'ENP'),
        ('Heart', 'Heart'),
        ('Emergency room', 'Emergency room'),
        ('Stock', 'Stock'),
    )
    name = models.CharField(max_length=200, null=True)
    department = models.CharField(max_length=264, null=True, choices=DEP)
    date_registered = models.DateTimeField(auto_now_add=True, null=True)
    objects = models.Manager()

    def __str__(self):
        return self.name


class RequestForm(models.Model):
    """make a Request object with that fields"""
    OPTION = {
        ('Add Equipment', 'Add Equipment'),
        ('Add Beds', 'Add Beds'),
    }
    name = models.CharField(max_length=264, null=True)
    request = models.CharField(max_length=264, null=True, choices=OPTION)
    description = models.TextField(max_length=264, null=True)
    date_registered = models.DateTimeField(auto_now_add=True, null=True)
    objects = models.Manager()

    def __str__(self):
        return self.name


class ReportForm(models.Model):
    """make a Report object with that fields"""
    OPTION = {
        ('Amount of patient', 'Amount of patient'),
        ('Amount of equipment', 'Amount of equipment'),
        ('Usage of equipment', 'Usage of equipment'),
        ('Treatment', 'Treatment'),
        ('General', 'General'),
    }
    DEP = (
        ('Corona', 'Corona'),
        ('ENP', 'ENP'),
        ('Heart', 'Heart'),
        ('Emergency room', 'Emergency room'),
    )
    name = models.CharField(max_length=264, null=True)
    choice = models.CharField(max_length=264, null=True, choices=OPTION)
    department = models.CharField(max_length=264, null=True, choices=DEP)
    description = models.TextField(max_length=264, null=True)
    date_registered = models.DateTimeField(auto_now_add=True, null=True)
    objects = models.Manager()


class Department(models.Model):
    """make a Department object with that fields"""

    DEP = (
        ('Corona', 'Corona'),
        ('ENP', 'ENP'),
        ('Heart', 'Heart'),
        ('Emergency room', 'Emergency room'),
    )
    department = models.CharField(max_length=200, null=True, choices=DEP, default='Corona')
    objects = models.Manager()

    def __str__(self):
        return self.department
