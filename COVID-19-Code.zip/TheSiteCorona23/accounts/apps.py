from django.apps import AppConfig

#name of our app
class AccountsConfig(AppConfig):
    name = 'accounts'
